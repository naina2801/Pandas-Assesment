import pandas as pd
df = pd.read_excel("assesment4.xlsx")
df1 = pd.DataFrame(df)
df1['new'] = df1["Quantity"] * df1["Unit Price"]
df1["Edited Output"] = df1["new"] == df1["Amount"]
print(df1.drop(['new'], axis=1,inplace=True))
print(df1.to_excel("asm4op.xlsx"))
