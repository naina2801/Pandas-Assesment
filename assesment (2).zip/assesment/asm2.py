import pandas as pd
df = pd.read_excel("assesment2.xlsx")

df['Amount'] = df["Quantity"] * df["Unit Price"]
print(df.to_excel("asm2op.xlsx",index=False))
