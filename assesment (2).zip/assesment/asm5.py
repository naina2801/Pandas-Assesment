import pandas as pd
import numpy as np
df = pd.read_excel("assesment5.xlsx")
# print(df)
df['new'] = df["UnitPrice"] + df["GSD"]
df['Quantity'] = df["Amount"] / df['new']
print(df.drop(['new'], axis=1,inplace=True))
print(df.round())