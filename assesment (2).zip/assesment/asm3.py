import pandas as pd
# from datetime import datetime
# customdp = datetime.strptime("%d-%m-%y")
# df = pd.read_csv("assesment3.csv",parse_dates=["Date Of\nService"])
df = pd.read_csv("assesment3.csv")
# print(df.to_string())
df['Date Of\nService'] = pd.to_datetime(df['Date Of\nService'], errors='coerce')
df['Date Of\nService'] = df['Date Of\nService'].dt.strftime('%Y/%m/%d')

print(df.to_excel("asm3op.xlsx"))
