import pandas as pd
df = pd.read_excel("assesment1.xlsx")

# df[["Unit Price",'Amount']] = df["Unit Price"].str.split(' ',expand=True)
# df[["Unit Price",'Amount']] = df["Amount"].str.split(' ',expand=True)

# print(df.head(7).to_excel("as1.xlsx"))
# print(df.tail(12).to_excel("as2.xlsx"))

df1 = pd.read_excel("as1.xlsx")
df2 = pd.read_excel("as2.xlsx")
df3= pd.concat([df1,df2])
print(df3.to_excel("asm1op.xlsx",index=False))
